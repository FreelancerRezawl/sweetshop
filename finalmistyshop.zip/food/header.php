<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="homepage.png">
    <title>Home</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
   
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="home">
    
       
        <header id="header" class="header-scroll top-header headrom">
          
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> <h2 style="color: white;">মিষ্টি বাংলা </h2></a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                            <li class="nav-item"> <a class="nav-link active" href="index.php">হোম <span class="sr-only">(current)</span></a> </li>
                            
                            <li class="nav-item"> <a class="nav-link active" href="dishes.php">সকল মিষ্টি                            <span class="sr-only"></span></a> </li>
                        
                           
							<?php
						if(empty($_SESSION["user_id"])) 
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">সাইন ইন</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active">সাইন আপ</a> </li>';
							}
						else
							{
									
									
                                    echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">আমার অর্ডার</a> </li>
                                    <li class="nav-item"><a href="profile.php" class="nav-link active">আমার প্রোফাইল</a> </li>';
							}

						?>
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
            
        </header>
