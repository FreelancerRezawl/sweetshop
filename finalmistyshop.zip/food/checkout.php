<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="homepage.png">
    <title>Checkout</title>
   
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script>
        function validateForm() {
            var paymentMethod = document.querySelector('input[name="mod"]:checked').value;
            var paymentOption = document.getElementById("payment").value;
            var phoneNumber = document.getElementById("pnumber").value;

            if (paymentMethod === "paypal" && (!paymentOption || phoneNumber === "")) {
                alert("Please select an online payment method and enter your phone number.");
                return false;
            }
            return true;
        }
    </script>
</head>

<body class="home">
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php">
                    <h2 style="color: white;">মিষ্টি বাংলা </h2>
                </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"><a class="nav-link active" href="index.php">হোম <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link active" href="dishes.php">সকল মিষ্টি <span class="sr-only"></span></a></li>
                        <li class="nav-item"><a class="nav-link active" href="your_orders.php">আমার অর্ডার<span class="sr-only"></span></a></li>
                        <li class="nav-item"><a class="nav-link active" href="profile.php">আমার প্রোফাইল <span class="sr-only"></span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <?php
    include("connection/connect.php");
    include_once 'product-action.php';
    error_reporting(0);
    session_start();
    if(empty($_SESSION["user_id"])) {
        header('location:login.php');
    } else {
        foreach ($_SESSION["cart_item"] as $item) {
            $item_total += ($item["price"]*$item["quantity"]);
            if($_POST['submit']) {
                $SQL="insert into users_orders(u_id,title,quantity,price) values('".$_SESSION["user_id"]."','".$item["title"]."','".$item["quantity"]."','".$item["price"]."')";
                mysqli_query($db,$SQL);
                $success = "Thank you! Your Order Placed Successfully!";
            }
        }
    ?>

    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="restaurants.php"> পছন্দ করুন </a></li>
                    <li class="col-xs-12 col-sm-4 link-item "><span>2</span><a href="#">অর্ডার করুন </a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>3</span><a href="checkout.php">হাতে পেয়ে মুল্য পরিশোধ করুন</a></li>
                </ul>
            </div>
        </div>
        <div class="container">
            <span style="color:green;">
                <?php echo $success; ?>
            </span>
        </div>
        <div class="container m-t-30">
            <form action="" method="post" onsubmit="return validateForm()">
                <div class="widget clearfix">
                    <div class="widget-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="cart-totals margin-b-20">
                                    <div class="cart-totals-title">
                                        <h4>Cart Summary</h4>
                                    </div>
                                    <div class="cart-totals-fields">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td>Cart Subtotal</td>
                                                    <td> &#2547;<?php echo $item_total; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Shipping &amp; Handling</td>
                                                    <td>FREE*</td>
                                                <tr>
                                                    <td class="text-color"><strong>Total</strong></td>
                                                    <td class="text-color"><strong> &#2547;<?php echo $item_total; ?></strong></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="payment-option">
                                    <ul class="list-unstyled">
                                        <li>
                                            <label class="custom-control custom-radio m-b-20">
                                                <input name="mod" id="radioStacked1" checked value="COD" type="radio" class="custom-control-input"> 
                                                <span class="custom-control-indicator"></span> 
                                                <span class="custom-control-description">Cash on delivery</span>
                                            </label>
                                        </li>
                                        <li>
                                            <label class="custom-control custom-radio m-b-10">
                                                <input name="mod" type="radio" value="paypal" class="custom-control-input"> 
                                                <span class="custom-control-indicator"></span> 
                                                <span class="custom-control-description">Online Payment <img src="payment.png" alt="" width="90"></span>
                                            </label>
                                        </li>
                                        <label for="">প্রেমেন্ট ম্যাথোড সিলেক্ট করুন </label> 
                                        <br>
                                        <select name="payment" id="payment">
                                            <option value="" disabled selected>Select Payment Method</option>
                                            <option value="Bikash" class="Bikash">বিকাশ </option>
                                            <option value="nagad" class="nagad">নগদ</option>
                                            <option value="rocket" class="rocket"> রকেট</option>
                                        </select>
                                        <br>
                                        <label for="fname" class="fname"> আপনার ফোন নাম্বার দিন  </label>
                                        <br>
                                        <input type="number" id="pnumber" name="pnumber" value="" placeholder="Phone Number">
                                        <br><br>
                                    </ul>
                                    <p class="text-xs-center">
                                        <input type="submit" onclick="return confirm('Are you sure?');" name="submit" class="btn btn-outline-success btn-block" value="Order now">
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php include('footer.php')?>
    <?php } ?>
</body>
