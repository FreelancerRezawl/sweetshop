<!DOCTYPE html>
<html lang="en">
<?php
session_start();
error_reporting(0);
include("connection/connect.php");
if (isset($_POST['submit'])) {
    if (
        empty($_POST['firstname']) ||
        empty($_POST['lastname']) ||
        empty($_POST['email']) ||
        empty($_POST['phone']) ||
        empty($_POST['password']) ||
        empty($_POST['cpassword'])
    ) {
        $message = "All fields must be Required!";
    } else {
        $check_username = mysqli_query($db, "SELECT username FROM users where username = '" . $_POST['username'] . "' ");
        $check_email = mysqli_query($db, "SELECT email FROM users where email = '" . $_POST['email'] . "' ");

        if ($_POST['password'] != $_POST['cpassword']) {
            $message = "Password not match";
        } elseif (strlen($_POST['password']) < 6) {
            $message = "Password Must be >=6";
        } elseif (strlen($_POST['phone']) < 11) {
            $message = "invalid phone number!";
        } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $message = "Invalid email address please type a valid email!";
        } elseif (mysqli_num_rows($check_username) > 0) {
            $message = 'username Already exists!';
        } elseif (mysqli_num_rows($check_email) > 0) {
            $message = 'Email Already exists!';
        } else {
            $mql = "INSERT INTO users(username,f_name,l_name,email,phone,password,address) VALUES('" . $_POST['username'] . "','" . $_POST['firstname'] . "','" . $_POST['lastname'] . "','" . $_POST['email'] . "','" . $_POST['phone'] . "','" . md5($_POST['password']) . "','" . $_POST['address'] . "')";
            mysqli_query($db, $mql);
            $success = "Account Created successfully! <p>You will be redirected in <span id='counter'>5</span> second(s).</p>
                                                        <script type='text/javascript'>
                                                        function countdown() {
                                                            var i = document.getElementById('counter');
                                                            if (parseInt(i.innerHTML) <= 0) {
                                                                location.href = 'login.php';
                                                            }
                                                            i.innerHTML = parseInt(i.innerHTML) - 1;
                                                        }
                                                        setInterval(function () { countdown(); }, 1000);
                                                        </script>'";
            header("refresh:5;url=login.php");
        }
    }
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Reg</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            margin: 0;
        }
        .main-content {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding-top: 70px;
        }
        .widget-body {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .btn.theme-btn {
            background-color: #f30;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .btn.theme-btn:hover {
            background-color: #d02525;
        }
        .form-control {
            border-radius: 5px;
        }
    </style>
</head>
<body>
   <?php include('header.php')?>
    <div class="main-content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="widget">
                        <div class="widget-body">
                            <div class="breadcrumb">
                                <ul>
                                    <li>
                                        <span style="color:red;"><?php echo $message; ?></span>
                                        <span style="color:green;"><?php echo $success; ?></span>
                                    </li>
                                </ul>
                            </div>
                            <form action="" method="post">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        <label for="exampleInputEmail1">User Name</label>
                                        <input class="form-control" type="text" name="username" id="example-text-input" placeholder="UserName">
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputEmail1">First Name</label>
                                        <input class="form-control" type="text" name="firstname" id="example-text-input" placeholder="First Name">
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputEmail1">Last Name</label>
                                        <input class="form-control" type="text" name="lastname" id="example-text-input-2" placeholder="Last Name">
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"> <small id="emailHelp" class="form-text text-muted">We"ll never share your email with anyone else.</small>
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputEmail1">Phone number</label>
                                        <input class="form-control" type="text" name="phone" id="example-tel-input-3" placeholder="Phone"> <small class="form-text text-muted">We"ll never share your email with anyone else.</small>
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="exampleInputPassword1">Repeat password</label>
                                        <input type="password" class="form-control" name="cpassword" id="exampleInputPassword2" placeholder="Password">
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="exampleTextarea">Delivery Address</label>
                                        <textarea class="form-control" id="exampleTextarea" name="address" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p> <input type="submit" value="Register" name="submit" class="btn theme-btn"> </p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</body>
</html>
