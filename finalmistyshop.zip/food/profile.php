<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="homepage.png">
    <title>Home</title>
  
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

     <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
     <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/login.css">


</head>

<body class="home">
    
       
        <header id="header" class="header-scroll top-header headrom">
          
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> <h2 style="color: white;">মিষ্টি বাংলা </h2></a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                            <li class="nav-item"> <a class="nav-link active" href="index.php">হোম <span class="sr-only">(current)</span></a> </li>
                            
                            
                            <li class="nav-item"> <a class="nav-link active" href="dishes.php">সকল মিষ্টি<span class="sr-only"></span></a> </li>
                      
                            <li class="nav-item"> <a class="nav-link active" href="your_orders.php">আমার অর্ডার                            <span class="sr-only"></span></a> </li>
                            <li class="nav-item"> <a class="nav-link active" href="profile.php">আমার প্রোফাইল <span class="sr-only"></span></a> </li>
                        
                           
							
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
          
        </header>
	  <style type="text/css">
	  #buttn{
		  color:#fff;
		  background-color: #ff3300;
	  }
	  </style>
  
</head>

<body>


<div class="pen-title">
  <br>
  <img src="images/user.png" alt="" style="width: 150px;">
  <b><h1>Welcome ! </h1></b>
</div>

<div class="module form-module">
  <div class="toggle">
   
  </div>
  <div class="form">
  <div class="cta"><a href="your_orders.php" style="color:#f30;"> <button>আর্ডারটি দেখুন</button> </a></div>
  <div class="cta"><a href="dishes.php" style="color:#f30;"> <button>সকল মিষ্টি </button> </a></div>
  <div class="cta"><a href="index.php" style="color:#f30;"> <button>মেইন মেনু তে ফিরুন </button> </a></div>
  <div class="cta"><a href="logout.php" style="color:#f30;"> <button>সাইন আউট </button> </a></div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

   



</body>

</html>
